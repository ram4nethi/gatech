// Inside your Table component
import React from 'react';
import { Table as MuiTable, TableBody, TableCell, Button, TableContainer, TableHead, TableRow, Paper, Box } from '@mui/material';

const Table = ({ data, onViewClick, authenticatedRole }) => {
  const commonColumns = [
    { field: 'vehicletype', headerName: 'Vehicle Type', width: 150 },
    { field: 'modelname', headerName: 'Model Name', width: 150 },
    { field: 'modelyear', headerName: 'Model Year', width: 150 },
    { field: 'manufacturername', headerName: 'Manufacturer', width: 150 },
    { field: 'fueltype', headerName: 'Fuel Type', width: 150 },
    { field: 'Mileage', headerName: 'Mileage', width: 150 }, // Adjust this based on your actual data
    { field: 'Description', headerName: 'Description', width: 150 }, // Adjust this based on your actual data
    { field: 'salesprice', headerName: 'Sales Price', width: 150 },
  ];

  const salesPersonColumns = [
    // Additional columns specific to Sales Person
  ];

  const invClerkManagerColumns = [
    { field: 'vin', headerName: 'VIN', width: 150 },
    ...commonColumns,
    { field: 'mileage', headerName: 'Mileage', width: 150 }, // Adjust this based on your actual data
    { field: 'description', headerName: 'Description', width: 150 }, // Adjust this based on your actual data
    { field: 'condition', headerName: 'Condition', width: 150 }, // Adjust this based on your actual data
    { field: 'purchaseprice', headerName: 'Purchase Price', width: 150 }, // Adjust this based on your actual data
    { field: 'Purchasedate', headerName: 'Purchase Date', width: 150 }, // Adjust this based on your actual data
    ...salesPersonColumns,
  ];

  console.log(authenticatedRole, "Roleeeeeeeeeeeeeee")

  const columns = authenticatedRole === 'INV_CLERK' || authenticatedRole === 'MANAGER'
    ? invClerkManagerColumns
    : commonColumns;

  const handleViewClick = (item) => {
    if (onViewClick) {
      onViewClick(item);
    }
  };

  return (
    <Box margin={2} marginBottom={2}>
      <TableContainer component={Paper} style={styles.container}>
        <MuiTable>
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column.field}><b>{column.headerName}</b></TableCell>
              ))}
              <TableCell><b>View</b></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((item) => (
              <TableRow key={item.vin}>
                {columns.map((column) => (
                  <TableCell key={column.field}>{item[column.field]}</TableCell>
                ))}
                <TableCell>
                  <Button
                    variant="contained"
                    onClick={() => handleViewClick(item)}
                    style={{ background: '#2196F3', color: 'white', borderRadius: '5px', cursor: 'pointer' }}
                  >
                    View
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </MuiTable>
      </TableContainer>
    </Box>
  );
};

const styles = {
  container: {
    marginTop: '20px',
  },
};

export default Table;
