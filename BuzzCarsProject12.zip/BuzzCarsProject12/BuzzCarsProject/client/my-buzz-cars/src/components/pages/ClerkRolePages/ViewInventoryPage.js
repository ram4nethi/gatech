import React, { useState, useEffect } from 'react';
import SearchBar from '../../SearchBar'; 
import Table from '../../Table'; 
import { Paper, Box, Card, CardContent, Typography } from '@mui/material';
import VehicleDetailForm from './VehicleDetailForm';

const ViewInventory = ({selectedItem, onClose}) => {
  const [searchResults, setSearchResults] = useState([]);
  const [vehicleCount, setVehicleCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true); // Add loading state
  const [filteredData, setFilteredData] = useState([]);
  const [isViewClicked, setisViewClicked] = useState(false);
  const [selectedViewItem, setSelectedViewItem] = useState(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [purchaseCount, setPurchaseCount] = useState('');
  const [carsAvailablePurchaseCount, setCarsAvailablePurchaseCount] = useState('');
  const [poCount, setPoCount] = useState('');


  useEffect(() => {
    const handleSearch = async () => {
      try {
        setIsLoading(true);

        const response = await fetch('http://54.82.2.9:3001/api/vehicles');
        const data = await response.json();

        //setVehicleCount(data.length);
        setFilteredData(data);

      } catch (error) {
        console.error('Error fetching or filtering data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    handleSearch();
  }, []);

  
  useEffect(() => {
    const handleSearch = async () => {
      try {
        setIsLoading(true);

        const response = await fetch('http://54.82.2.9:3001/api/purchase-count');
        const data = await response.json();

     
        const countValue = data[0]["purchased_count"];
        setPurchaseCount(countValue);

      } catch (error) {
        console.error('Error fetching or filtering data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    handleSearch();
  }, []);

  useEffect(() => {
    // Fetch the count of vehicles from the server
    const fetchVehicleCount = async () => {
      try {
        const response = await fetch('http://54.82.2.9:3001/countItems');
        const data = await response.json();

        if (response.ok) {
          const countValue = data[0]["COUNT(v.vin)"];
          setVehicleCount(countValue);
        } else {
          console.error('Error fetching vehicle count:', data);
        }
      } catch (error) {
        console.error('Error fetching vehicle count:', error);
      }
    };

    fetchVehicleCount();
  }, []);

  useEffect(() => {
    const fetchPoCount = async () => {
      try {
        setIsLoading(true);
  
        const response = await fetch('http://54.82.2.9:3001/api/po-count');
        const data = await response.json();
  
        if (response.ok) {
          const poCountValue = data.poCount;
          setPoCount(poCountValue);  // Add this line to set the poCount in state
        } else {
          console.error('Error fetching part order count:', data);
        }
      } catch (error) {
        console.error('Error fetching part order count:', error);
      } finally {
        setIsLoading(false);
      }
    };
  
    fetchPoCount();
  }, []);
  

  useEffect(() => {
    // Fetch the count of vehicles from the server
    const carCountPurchase = async () => {
      try {
        const response = await fetch('http://54.82.2.9:3001/cars-available-purchase');
        const data = await response.json();

        if (response.ok) {
          const countAvailablePurchase = data[0]["count(vin)"];
          setCarsAvailablePurchaseCount(countAvailablePurchase);
        } else {
          console.error('Error fetching vehicle count:', data);
        }
      } catch (error) {
        console.error('Error fetching vehicle count:', error);
      }
    };

    carCountPurchase();
  }, []);

  const handleViewClick = (item) => {
    setSelectedViewItem(item);
    setIsDetailDialogOpen(true);
  };

  const handleSearch = async (filters) => {
    try {
      setIsLoading(true);
  
      const response = await fetch('http://54.82.2.9:3001/api/vehicles');
      const data = await response.json();
  
      // Apply filtering based on the received data
      const filtered = data.filter((item) => {
        const searchTextMatch =
          item.manufacturername.toLowerCase().includes(filters.searchText.toLowerCase()) ||
          item.modelname.toLowerCase().includes(filters.searchText.toLowerCase());
  
        const modelTypeMatch = filters.modelType === '' || item.vehicletype.toLowerCase() === filters.modelType.toLowerCase();
        const modelYearMatch = filters.modelYear === '' || item.modelyear.toString() === filters.modelYear;
  
        return searchTextMatch && modelTypeMatch && modelYearMatch;
      });
      console.log(filtered);
      console.log(data.length);
      //setVehicleCount(data.length);
      setFilteredData(filtered);
    } catch (error) {
      console.error('Error fetching or filtering data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <Paper elevation={3} style={{ padding: '20px', marginTop: '20px', textAlign: 'center', width:'100%', }}>
      <div style={{display:'flex'}}>
        <Card style={{ maxWidth: '200px', margin: 'auto', marginBottom: '20px' }}>
          <CardContent>
            <Typography variant="h6" component="div">
              Total number of cars available
            </Typography>
            <Typography variant="h4" component="div">
              {vehicleCount}
            </Typography>
          </CardContent>
        </Card>

        <Card style={{ maxWidth: '200px', margin: 'auto', marginBottom: '20px' }}>
        <CardContent>
          <Typography variant="h6" component="div">
            Total Cars with parts pending:
          </Typography>
          <Typography variant="h4" component="div">
            {poCount}
          </Typography>
        </CardContent>
        </Card>


        <Card style={{ maxWidth: '200px', margin: 'auto', marginBottom: '20px' }}>
          <CardContent>
            <Typography variant="h6" component="div">
              Total cars available for purchase
            </Typography>
            <Typography variant="h4" component="div">
              {carsAvailablePurchaseCount}
            </Typography>
          </CardContent>
        </Card>
        
        <Card style={{ maxWidth: '200px', margin: 'auto', marginBottom: '20px' }}>
          <CardContent>
            <Typography variant="h6" component="div">
              Cars Previously Purchased Count
            </Typography>
            <Typography variant="h4" component="div">
              {purchaseCount}
            </Typography>
          </CardContent> 
        </Card>

        </div>

        <SearchBar onSearch={handleSearch} />
        <Table data={filteredData} onViewClick={handleViewClick} />

        {isDetailDialogOpen && (
        <VehicleDetailForm
          open={isDetailDialogOpen}
          onClose={() => setIsDetailDialogOpen(false)}
          selectedItem={selectedViewItem}
        />
      )}
      </Paper>
    </div>
  );
};

export default ViewInventory;
