import React from "react";
import { Typography } from "@mui/material";
import {DialogActions, Button} from "@mui/material";
const BlankOwnerPage = () => {
    return (
      <div>
    <DialogActions sx={{ marginY: 2 }}>
        <h1>O</h1>

      </DialogActions>
      </div>
    );
  };

  export default BlankOwnerPage;