// SearchCustomerForm.js
import React, { useState } from 'react';
import { Paper, TextField, Button, InputLabel } from '@mui/material';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const SearchCustomerForm = () => {
  const [driverLicNum, setDriverLicNum] = useState('');
  const [taxID, setTaxID] = useState('');

  const handleSearchByDriverLicNum  = async () => {
    if (!driverLicNum && !taxID) {
      toast.error('Please enter either Driver License Number or Tax ID.');
      return;
    }
    
    try {
      const response = await fetch('http://54.90.194.32:3001/api/search-DrivNum', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          driverLicNum,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        const customerExists = data.customerExists;

        if (customerExists) {
          toast.success('Customer exists!');
          // Add logic to return to the previous screen or navigate to the Add Vehicle Form
        } else {
          toast.info('Customer does not exist!');
          // Add logic to navigate to the Add Customer Form
        }
      } else {
        console.error('Error searching for customer:', data);
        toast.error('Error searching for customer. Please try again.');
      }
    } catch (error) {
      console.error('Error searching customer:', error);
      toast.error('Error searching for customer. Please try again.');
    }
  };


  const handleSearchByTaxID = async () => {
    if (!taxID) {
      toast.error('Please enter Tax ID.');
      return;
    }

    try {
      const response = await fetch('http://54.90.194.32:3001/api/search-taxid', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          taxID,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        const customerExists = data.customerExists;

        if (customerExists) {
          toast.success('Customer with Tax ID exists!');
          // Add logic to return to the previous screen or navigate to the relevant form
        } else {
          toast.info('Customer with Tax ID does not exist!');
          // Add logic to navigate to the relevant form
        }
      } else {
        console.error('Error searching for customer:', data);
        toast.error('Error searching for customer. Please try again.');
      }
    } catch (error) {
      console.error('Error searching customer:', error);
      toast.error('Error searching for customer. Please try again.');
    }
  };

  return (
    <div>
      <Paper elevation={3} style={{ padding: '20px', marginTop: '20px', textAlign: 'center' }}>
        <h2 style={{ marginBottom: '15px' }}>Search Customer Form</h2>
        <TextField
          label="Enter Driver License Number"
          variant="outlined"
          value={driverLicNum}
          onChange={(e) => {
            setDriverLicNum(e.target.value);
            setTaxID(''); // Clear Tax ID when Driver License Number is entered
          }}
          fullWidth
          style={{ margin: '20px' }}
        />
                <Button
          variant="contained"
          onClick={handleSearchByDriverLicNum}
          style={{ background: '#4CAF50', color: 'white', borderRadius: '5px', cursor: 'pointer', marginRight: '10px' }}
        >
          Search by Driver License Number
        </Button>
        <InputLabel>OR</InputLabel>
        <TextField
          label="Enter Tax ID"
          variant="outlined"
          value={taxID}
          onChange={(e) => {
            setTaxID(e.target.value);
            setDriverLicNum(''); // Clear Driver License Number when Tax ID is entered
          }}
          fullWidth
          style={{ margin: '20px' }}
        />
        <Button
          variant="contained"
          onClick={handleSearchByTaxID}
          style={{ background: '#4CAF50', color: 'white', borderRadius: '5px', cursor: 'pointer' }}
        >
          Search by Tax ID
        </Button>
      </Paper>
    </div>
  );
};

export default SearchCustomerForm;
