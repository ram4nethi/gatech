import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const AddPartsForm = ({ onClose, vendorName }) => {
  const [formData, setFormData] = useState({
    vin: '',
    partOrderNumber: '',
    partNumber: '',
    status: '',
    quantity: '',
    cost: '',
    vendorName: vendorName,
    customeridsoldto: null,
    description:'',
  });

  const [error, setError] = useState('');
  const [vinNumbers, setVinNumbers] = useState([]);
  const [isCarSold, setIsCarSold] = useState(false);

  useEffect(() => {
    const fetchVinNumbers = async () => {
      try {
        const response = await fetch('http://54.82.2.9:3001/api/vinNumbers');
        const data = await response.json();

        if (response.ok) {
          setVinNumbers(data.vinNumbers);
        } else {
          console.error('Error fetching VIN numbers:', data);
        }
      } catch (error) {
        console.error('Error fetching VIN numbers:', error);
        setError('Error fetching VIN numbers. Please try again.');
      }
    };

    fetchVinNumbers();
  }, []); // Run this effect only once on component mount

  useEffect(() => {
    // Fetch customeridsoldto based on the selected VIN
    const fetchCustomerIdsoldto = async () => {
      try {
        const response = await fetch(`http://54.82.2.9:3001/api/check-car-sold/${formData.vin}`);
        const data = await response.json();
        console.log(data, "My ")
    
        if (response.ok) {
          // Update the formData with customeridsoldto
          setFormData((prevData) => ({
            ...prevData,
            customeridsoldto: data.customeridsoldto,
          }));
    
          // Check if the car is sold
          setIsCarSold(data.sold); // Update to use 'sold' instead of 'customeridsoldto'
        } else {
          console.error('Error fetching customeridsoldto:', data.error);
          // Handle error, e.g., display a message to the user
        }
      } catch (error) {
        console.error('Error fetching customeridsoldto:', error);
        // Handle error, e.g., display a message to the user
      }
    };

    if (formData.vin) {
      // Only fetch customeridsoldto if VIN is selected
      fetchCustomerIdsoldto();
    }
  }, [formData.vin]);

  const handleInputChange = (field, value) => {
    setFormData((prevData) => ({ ...prevData, [field]: value }));
  };

  const handleAddPart = async () => {
    try {
      // Validate the form data
      if (Object.values(formData).some((value) => value === '')) {
        setError('Please enter all required values.');
        return;
      }

      // Additional validation for VIN (must be a number)
      const vinNumber = Number(formData.vin);
      if (isNaN(vinNumber)) {
        setError('VIN must be a number.');
        return;
      }

      // Additional validation for partOrderNumber, partNumber, quantity, cost (must be a number)
      const numericFields = ['partOrderNumber', 'partNumber', 'quantity', 'cost'];
      for (const field of numericFields) {
        const fieldValue = Number(formData[field]);
        if (isNaN(fieldValue)) {
          setError(`${field.charAt(0).toUpperCase() + field.slice(1)} must be a number.`);
          return;
        }
      }


      if (!isCarSold) {
        // Display a notification that the selected vehicle is sold
        toast.error('The selected vehicle is sold. Cannot add parts.');
        return;
      }

      // // Additional validation for status (must be a string)
      // const status = formData.status;
      // if (typeof status !== 'string') {
      //   setError('Status must be a string.');
      //   return;
      // }

      // Make API call to add part order
      const partOrderResponse = await fetch('http://54.82.2.9:3001/api/add-part-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vin: formData.vin,
          partOrderNumber: formData.partOrderNumber,
          vendorName: formData.vendorName,
        }),
      });

      const partOrderResult = await partOrderResponse.json();

      if (!partOrderResult.success) {
        console.error('Failed to add part order:', partOrderResult.error);
        setError('Failed to add part order. Please try again.');
        return;
      }

      // Make API call to add part
      const partResponse = await fetch('http://54.82.2.9:3001/api/add-part', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vin: formData.vin,
          partOrderNumber: formData.partOrderNumber,
          partNumber: formData.partNumber,
          status: formData.status,
          quantity: formData.quantity,
          cost: formData.cost,
          description: formData.description, // Replace with your description value
        }),
      });

      const partResult = await partResponse.json();

      if (!partResult.success) {
        console.error('Failed to add part:', partResult.error);
        setError('Failed to add part. Please try again.');
        return;
      }

      toast.success('Part added successfully');

      // Clear the form and error
      setFormData({
        vin: '',
        partOrderNumber: '',
        partNumber: '',
        status: '',
        quantity: '',
        cost: '',
        vendorName: '',
        customeridsoldto: null,
        description:''
      });
      setError('');
    } catch (error) {
      console.error('An unexpected error occurred:', error);
      setError('An unexpected error occurred. Please try again.');

      toast.error('Failed to add part. Please try again.');
    }
  };

  const handleContinue = () => {
    // Clear the form fields for the next part
    setFormData({
      ...formData,
      partOrderNumber: '',
      partNumber: '',
      status: '',
      quantity: '',
      cost: '',
      description: '',
    });
  };
  
  return (
    <Dialog open={true} onClose={onClose}>
      <DialogTitle>Add Parts</DialogTitle>
      <DialogContent>
        <TextField
          label="Vendor Name"
          variant="outlined"
          fullWidth
          value={formData.vendorName}
          onChange={(e) => handleInputChange('vendorName', e.target.value)}
        />
        <FormControl fullWidth>
          <InputLabel>VIN</InputLabel>
          <Select
            label="VIN"
            variant="outlined"
            value={formData.vin}
            onChange={(e) => handleInputChange('vin', e.target.value)}
          >
            {vinNumbers.map((vinNumber) => (
              <MenuItem key={vinNumber} value={vinNumber}>
                {vinNumber}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        {!isCarSold && (
          <>
        <TextField
          label="Part Order Number"
          variant="outlined"
          fullWidth
          value={formData.partOrderNumber}
          onChange={(e) => handleInputChange('partOrderNumber', e.target.value)}
        />
        <TextField
          label="Part Number"
          variant="outlined"
          fullWidth
          value={formData.partNumber}
          onChange={(e) => handleInputChange('partNumber', e.target.value)}
        />
        <FormControl fullWidth>
          <InputLabel>Status</InputLabel>
          <Select
            label="Status"
            variant="outlined"
            value={formData.status}
            onChange={(e) => handleInputChange('status', e.target.value)}
          >
            <MenuItem value="Ordered">Ordered</MenuItem>
            <MenuItem value="Received">Received</MenuItem>
            <MenuItem value="Installed">Installed</MenuItem>
          </Select>
        </FormControl>
        <TextField
          label="Quantity"
          variant="outlined"
          type="number"
          fullWidth
          value={formData.quantity}
          onChange={(e) => handleInputChange('quantity', e.target.value)}
        />
        <TextField
          label="Cost"
          variant="outlined"
          type="number"
          fullWidth
          value={formData.cost}
          onChange={(e) => handleInputChange('cost', e.target.value)}
        />

        <TextField
          label="Description"
          variant="outlined"
          fullWidth
          value={formData.description}
          onChange={(e) => handleInputChange('description', e.target.value)}
        />
        </>
        )}

        {/* Display error message */}
        {error && <p style={{ color: 'red' }}>{error}</p>}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        {!isCarSold && (
          <>
            <Button onClick={handleAddPart}>Add</Button>
            <Button onClick={handleContinue}>Continue</Button>
          </>
        )}
        {isCarSold && <Button onClick={onClose}>OK</Button>}
      </DialogActions>
      <ToastContainer />
    </Dialog>
  );
};

export default AddPartsForm;
