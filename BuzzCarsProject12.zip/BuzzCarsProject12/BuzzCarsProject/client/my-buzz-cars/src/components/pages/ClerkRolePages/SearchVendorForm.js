import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from '@mui/material';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const SearchVendorForm = ({ onClose }) => {
  const [searchResults, setSearchResults] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Fetch all vendors when the component mounts
    const fetchVendors = async () => {
      try {
        if (searchTerm) {
        const response = await fetch(`http://localhost:3001/api/search-vendors?searchTerm=${searchTerm}`);
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        setSearchResults(data);

        // Show toast notification based on search results
        if (data.length === 0) {
          toast.warning('Vendor doesn\'t exist. Please add a vendor.');
        } else {
          toast.success('Vendor exists.');
        }
      }
      } catch (error) {
        console.error('Error fetching vendors:', error);
        toast.error('Error fetching vendors. Please try again.');
      }
    };

    fetchVendors();
  }, [searchTerm]); // Include searchTerm in the dependency array to trigger the effect on search term change

  const handleCancel = () => {
    onClose();
  };

  const handleSearch = () => {
    // Trigger a re-fetch when the search button is clicked
    setSearchTerm(document.getElementById('searchInput').value);
  };

  return (
    <Dialog open={true} onClose={handleCancel}>
      <DialogTitle>Vendor List</DialogTitle>
      <DialogContent>
        <div>
          <TextField type="text" id="searchInput" placeholder="Search by vendor name" />
          <Button variant="contained" onClick={handleSearch}>Search</Button>
        </div>
        <TableContainer component={Paper} style={{ marginTop: '16px' }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Vendor Name</TableCell>
                <TableCell>Street</TableCell>
                <TableCell>City</TableCell>
                {/* Add other columns as needed */}
              </TableRow>
            </TableHead>
            <TableBody>
              {searchResults.map((vendor) => (
                <TableRow key={vendor.vendorname}>
                  <TableCell>{vendor.vendorname}</TableCell>
                  <TableCell>{vendor.street}</TableCell>
                  <TableCell>{vendor.city}</TableCell>
                  {/* Add other cells based on your database schema */}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleCancel}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default SearchVendorForm;
