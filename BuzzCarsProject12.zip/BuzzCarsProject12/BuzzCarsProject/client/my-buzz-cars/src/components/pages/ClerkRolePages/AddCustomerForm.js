import React, { useState } from 'react';
import { Paper, TextField, Button, Typography, Grid, Box, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import { toast } from 'react-toastify';
import { useEffect } from 'react';

import 'react-toastify/dist/ReactToastify.css';

const AddCustomerForm = ({onAddCustomer}) => {

  const [customerId, setCustomerId] = useState('');
  const [customerIds, setCustomerIds] = useState([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');

  const [personData, setPersonData] = useState({
    driverlicensenumber:'',
    customerid: '',
    firstname: '',
    lastname: '',
    street: '',
    city: '',
    state: '',
    postalcode: '',
    email: '',
    phonenumber: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    if (name === 'customerid') {
      // Update personData.customerid when customer is selected
      setPersonData((prevData) => ({
        ...prevData,
        customerid: value,
      }));
    } else {
      // Update other fields as usual
      setPersonData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };



  useEffect(() => {
    // Fetch customer IDs when the form opens
    const fetchCustomerIds = async () => {
    try {
        const response = await fetch('http://54.90.194.32:3001/api/customers');
        const data = await response.json();

        setCustomerIds(data);
    } catch (error) {
        console.error('Error fetching customer IDs:', error);
    }
    };

    fetchCustomerIds();
}, []);


  


  const handleAddCustomer = async () => {
    

    const customerData={
      customerid:customerId,
    };

    console.log(customerId, "my cust id ");

    
    try {
      const response = await fetch('http://54.90.194.32:3001/api/add-customer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(customerData),
      });

      const result = await response.json();

      if (result.success) {
        alert('Customer added successfully');
      } else {
        alert('Error adding customer: ' + result.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An unexpected error occurred');
    }
  };


  const handleAddPerson = async () => {

    //FOrm Validation
    const requiredFields = ['driverlicensenumber', 'firstname', 'lastname', 'street', 'city', 'state', 'postalcode', 'email', 'phonenumber'];
    const missingFields = requiredFields.filter((field) => !personData[field]);

    if (missingFields.length > 0) {
      // Display error toast for missing fields
      toast.error(`Please enter values for the following fields: ${missingFields.join(', ')}`);
      return;
    }

    // Additional format validation (you can customize this based on your requirements)

    // Check if customerid is a number
    // if (isNaN(personData.customerid)) {
    //   toast.error('Customer ID must be a number');
    //   return;
    // }

    // Check if phonenumber is a valid phone number
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(personData.phonenumber)) {
      toast.error('Please enter a valid phone number (10 digits)');
      return;
    }

    // Check if email is a valid email address
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(personData.email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    // If all validations pass, proceed with adding the customer
    // For now, just log the customer data to the console
    console.log('Person Data:', personData);

    const personDataWithCustomerId = {
      ...personData,
      customerid: selectedCustomerId, // or use customerId if it's appropriate
    };

    try {
      const response = await fetch('http://54.90.194.32:3001/api/add-person', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(personDataWithCustomerId),
      });

      const result = await response.json();

      if (result.success) {
        alert('Person added successfully');
        // Reset the form or perform any other actions on successful submission
      } else {
        alert('Error adding customer: ' + result.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An unexpected error occurred');
    }

    // You can now proceed with the database insertion queries
  };


  return (
    <div>
      <Paper elevation={3} style={{ padding: '20px', marginTop: '20px', textAlign: 'center' }}>
        <Typography variant="h5" style={{ marginBottom: '15px' }}>
          Add Customer Form
        </Typography>

        <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <TextField
          label="customer id"
          onChange={(e) => setCustomerId(e.target.value)}
          name='customerid'
          type="number"
          value={customerId}
          variant='outlined'
          fullWidth
          style={{ marginBottom: '20px' }}
          />
          </Grid>
          </Grid>
          <Button
          variant="contained"
          onClick={handleAddCustomer}
          style={{ background: '#4CAF50', color: 'white', borderRadius: '5px', cursor: 'pointer', marginTop: '20px' }}
        >
          Add Customer
        </Button>


        <Typography variant="h5" style={{ marginBottom: '15px' }}>
          Add Person Form
        </Typography>

          <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
            <TextField
              label="Driving License Number ID"
              variant="outlined"
              name="driverlicensenumber"
              type="number"
              value={personData.driverlicensenumber}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>

          <Box sx={{ marginBottom: 2 }}>
                <FormControl fullWidth variant="outlined">
                <InputLabel id="customer-id-label">Customer ID</InputLabel>
                <Select
                    labelId="customer-id-label"
                    id="customer-id"
                    value={selectedCustomerId}
                    onChange={(e) => setSelectedCustomerId(e.target.value)}
                    label="CustomerID"
                >
                    {customerIds.map((customerId) => (
                    <MenuItem key={customerId} value={customerId}>
                        {customerId}
                    </MenuItem>
                    ))}
                </Select>
                </FormControl>
            </Box>
            </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="First Name"
              variant="outlined"
              name="firstname"
              value={personData.firstname}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Last Name"
              variant="outlined"
              name="lastname"
              value={personData.lastname}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Street"
              variant="outlined"
              name="street"
              value={personData.street}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="City"
              variant="outlined"
              name="city"
              value={personData.city}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="State"
              variant="outlined"
              name="state"
              value={personData.state}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Postal Code"
              variant="outlined"
              name="postalcode"
              type="number"
              value={personData.postalcode}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Email"
              variant="outlined"
              name="email"
              value={personData.email}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Phone Number"
              variant="outlined"
              name="phonenumber"
              type="number"
              value={personData.phonenumber}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>
        </Grid>

        <Button
          variant="contained"
          onClick={handleAddPerson}
          style={{ background: '#4CAF50', color: 'white', borderRadius: '5px', cursor: 'pointer', marginTop: '20px' }}
        >
          Add Person
        </Button>
      </Paper>
    </div>
  );
};

export default AddCustomerForm;
