import React, { useState } from 'react';
import { Paper, TextField, Button, Box, Typography, Grid, MenuItem, Select, FormControl, InputLabel, colors } from '@mui/material';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useEffect } from 'react';

const NewVehicleForm = () => {


    const [vehicleData, setVehicleData] = useState({
        vin: '',
        inventoryclerk_email:'',
        vehicleType: '',
        modelname: '',
        modelyear: '',
        manufacturername: '',
        fuelType: '',
        mileage: '',
        customeridboughtfrom: '',
        description: '',
        purchasePrice: '',
        purchaseDate: '',
      });


        const [vehicleTypes, setVehicleTypes] = useState([]);
        const [fuelTypes, setFuelTypes] = useState([]);
        const [customerIDs, setCustomerIDs] = useState([]);
        const [clerkEmails, setclerkEmails] = useState([]);


        useEffect(() => {
            // Fetch data for dropdowns
            const fetchData = async () => {
              try {
                const vehicleTypesResponse = await fetch('http://54.90.194.32:3001/api/get-vehicle-types');
                const vehicleTypesData = await vehicleTypesResponse.json();
        
                const fuelTypesResponse = await fetch('http://54.90.194.32:3001/api/get-fuel-types');
                const fuelTypesData = await fuelTypesResponse.json();
        
                const customerIDsResponse = await fetch('http://54.90.194.32:3001/api/get-customer-ids');
                const customerIDsData = await customerIDsResponse.json();
        
                const colorsResponse = await fetch('http://54.90.194.32:3001/api/get-colors');
                const colorsData = await colorsResponse.json();

                const clerkemailResponse = await fetch('http://54.90.194.32:3001/api/get-clerkemail');
                const clerkemailData = await clerkemailResponse.json();
        
                setVehicleTypes(vehicleTypesData);
                setFuelTypes(fuelTypesData);
                setCustomerIDs(customerIDsData);
                // setColor(colorsData);
                setclerkEmails(clerkemailData);

              } catch (error) {
                console.error('Error fetching dropdown options:', error);
              }
            };
        
            fetchData();
          }, []);

          const handleInputChange = (e) => {
            const { name, value } = e.target;
            setVehicleData((prevData) => ({
              ...prevData,
              [name]: value,
            }));
          };

  const handleSelectChange = (name, value) => {
    setVehicleData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

//   const handleColorChange = (e) => {
//     const selectedColor = e.target.value;
//     setColorValue(selectedColor);
//   };

  const handleAddVehicle = async () => {
    // Form validation
    const requiredFields = [
        'vin',
        'inventoryclerk_email',
        'vehicleType',
        'modelname',
        'modelyear',
        'manufacturername',
        'fuelType',
        'mileage',
        'customeridboughtfrom',
        'description',
        'purchasePrice',
        'purchaseDate',
      ];


    const missingFields = requiredFields.filter((field) => !vehicleData[field]);


    console.log('Vehicle Data:', vehicleData);

    if (missingFields.length > 0) {
      // Display error toast for missing fields
      toast.error(`Please enter values for the following fields: ${missingFields.join(', ')}`);
      return;
    }

    try {
      const response = await fetch('http://54.90.194.32:3001/api/add-vehicle', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(vehicleData),
      });

      const vehicleResult = await response.json();

      if(vehicleResult.success){
        toast.success("Vehicle added successfully!!");
      }


    //   if (vehicleResult.success) {
    //     // Post color data
    //     const colorResponse = await fetch('http://54.90.194.32:3001/api/add-color', {
    //       method: 'POST',
    //       headers: {
    //         'Content-Type': 'application/json',
    //       },
    //       body: JSON.stringify({
    //         vin: vehicleData.vin,
    //         // color: color,
    //       }),
    //     });

    //     const colorResult = await colorResponse.json();

    //     if (colorResult.success) {
    //       toast.success('Vehicle and Color added successfully');
    //       // You can perform additional actions after saving if needed
    //     } else {
    //       toast.error('Error adding color: ' + colorResult.error);
    //     }
    //   } 
    // else {
    //     toast.error('Error adding vehicle: ' + vehicleResult.error);
    //   }
    } catch (error) {
      console.error('Error adding vehicle:', error);
      toast.error('An unexpected error occurred while adding the vehicle');
    }

    // Clear the form fields after adding a vehicle
    // You can also add more sophisticated form handling here
    // ... clear other form fields ...
  };




  return (

<Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          marginTop: 8,
          width: "100%"
        }}
      >
<Paper
        elevation={3}
        style={{ padding: '20px', marginTop: '20px', textAlign: 'center' }}
      >
        <h2 style={{ marginBottom: '15px' }}>New Vehicle Form</h2>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              label="VIN"
              variant="outlined"
              name="vin"
              type="number"
              value={vehicleData.vin}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
            <FormControl fullWidth variant="outlined" style={{ marginBottom: '20px' }}>
              <InputLabel>Inventory Clerk</InputLabel>
              <Select
                value={vehicleData.inventoryclerk_email}
                name="inventory_clerk"
                onChange={(e) => handleSelectChange('inventoryclerk_email', e.target.value)}
                label="Inventory Clerk Email"
              >
                {clerkEmails.map((id) => (
                  <MenuItem key={id} value={id}>
                    {id}
                  </MenuItem>
                ))}

              </Select>
            </FormControl>
            <FormControl fullWidth variant="outlined" style={{ marginBottom: '20px' }}>
              <InputLabel>Vehicle Type</InputLabel>
              <Select
                value={vehicleData.vehicleType}
                name="vehicleType"
                onChange={(e) => handleSelectChange('vehicleType', e.target.value)}
                label="Vehicle Type"
              >
                {vehicleTypes.map((type) => (
                  <MenuItem key={type} value={type}>
                    {type}
                  </MenuItem>
                ))}

              </Select>
            </FormControl>
            <TextField
              label="Mileage"
              variant="outlined"
              value={vehicleData.mileage}
              name="mileage"
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
            <FormControl fullWidth variant="outlined" style={{ marginBottom: '20px' }}>
              <InputLabel>Customer ID bought from</InputLabel>
              <Select
                value={vehicleData.customeridboughtfrom}
                name="customeridboughtfrom"
                onChange={(e) => handleSelectChange('customeridboughtfrom', e.target.value)}
                label="Customer ID bought from"
              >
                {customerIDs.map((id) => (
                  <MenuItem key={id} value={id}>
                    {id}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              label="Description"
              variant="outlined"
              name="description"
              value={vehicleData.description}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
                       <TextField
              label="Purchase Price"
              variant="outlined"
              name="purchasePrice"
              type='number'
              value={vehicleData.purchasePrice}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Model Name"
              variant="outlined"
              name="modelname"
              value={vehicleData.modelname}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
            <TextField
              label="Model Year"
              variant="outlined"
              name="modelyear"
              type="number"
              value={vehicleData.modelyear}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
            <TextField
              label="Manufacturer Name"
              variant="outlined"
              name="manufacturername"
              value={vehicleData.manufacturername}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
            <FormControl fullWidth variant="outlined" style={{ marginBottom: '20px' }}>
              <InputLabel>Fuel Type</InputLabel>
              <Select
                value={vehicleData.fuelType}
                name="fuelType"
                onChange={handleInputChange}
                label="Fuel Type"
              >
                {fuelTypes.map((type) => (
                  <MenuItem key={type} value={type}>
                    {type}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {/* <TextField
              label="Condition"
              variant="outlined"
              name="condition"
              value={vehicleData.condition}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            /> */}
 
            <TextField
              label="Purchase Date"
              variant="outlined"
              name="purchaseDate"
              type="date"
              value={vehicleData.purchaseDate}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
            {/* <FormControl fullWidth variant="outlined" style={{ marginBottom: '20px' }}>
            <InputLabel>Colors</InputLabel>
            <Select
                name="color"
                label="Colors"
            >
                {colors.map((color) => (
                <MenuItem key={color} value={color}>
                    {color}
                </MenuItem>
                ))}
            </Select>
            </FormControl> */}
          </Grid>
        </Grid>
        <Button
          variant="contained"
          onClick={handleAddVehicle}
          style={{
            background: '#4CAF50',
            color: 'white',
            borderRadius: '5px',
            cursor: 'pointer',
          }}
        >
          Add Vehicle
        </Button>
      </Paper>

      </Box>
  );
};

export default NewVehicleForm;