import React, { useEffect, useState } from "react";
import { Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from "@mui/material";

const MonthlySalesComponent = () => {
  // Assuming you are using useState to manage selectedYear and selectedMonth
  const [selectedYear, setSelectedYear] = useState(/* initial value */);
  const [selectedMonth, setSelectedMonth] = useState(/* initial value */);
  const [monthlySalesData, setMonthlySalesData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMonthlySalesData = async () => {
      try {
        const response = await fetch(`http://54.90.194.32:3001/api/monthly-sales`);
        const data = await response.json();

        if (response.ok) {
          setMonthlySalesData(data);
        } else {
          console.error('Error fetching monthly sales data:', data.error);
        }
      } catch (error) {
        console.error('Error fetching monthly sales data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMonthlySalesData();
  }, []);

  return (
    <div>

      {loading ? (
        <p>Loading...</p>
      ) : monthlySalesData ? (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Year</TableCell>
                <TableCell>Month</TableCell>
                <TableCell>Total Vehicles Sold</TableCell>
                <TableCell>Total Sales Income</TableCell>
                <TableCell>Total Net Income</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {monthlySalesData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell>{row.year}</TableCell>
                  <TableCell>{row.month}</TableCell>
                  <TableCell>{row.totalvehiclessold}</TableCell>
                  <TableCell>{row.totalsalesincome}</TableCell>
                  <TableCell>{row.totalnetincome}</TableCell>

                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      ) : (
        <p>Error fetching monthly sales data</p>
      )}
    </div>
  );
};

export default MonthlySalesComponent;
