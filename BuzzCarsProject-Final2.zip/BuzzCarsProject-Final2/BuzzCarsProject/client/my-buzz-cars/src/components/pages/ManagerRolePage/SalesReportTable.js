import React, { useState, useEffect } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';

const SalesReportTable = () => {
  const [salesData, setSalesData] = useState([]);

  useEffect(() => {
    const fetchSalesReport = async () => {
      try {
        const response = await fetch('http://54.90.194.32:3001/api/sales-report');
        const data = await response.json();

        if (response.ok) {
          setSalesData(data);
        } else {
          console.error('Error fetching sales report:', data);
        }
      } catch (error) {
        console.error('Error fetching sales report:', error);
      }
    };

    fetchSalesReport();
  }, []);

  return (
    <div>
    
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Sales Year</TableCell>
              <TableCell>Sales Month</TableCell>
              <TableCell>Total Vehicles Sold</TableCell>
              <TableCell>Total Purchase Price</TableCell>
              <TableCell>Total Net</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {salesData.map((record) => (
              <TableRow key={record.email}>
                <TableCell>{record.r_year}</TableCell>
                <TableCell>{record.r_month}</TableCell>
                <TableCell>{record.tot_veh_sold}</TableCell>
                <TableCell>{record.tot_pur_price}</TableCell>
                <TableCell>{record.tot_net}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default SalesReportTable;
