import React from "react";
import { Typography } from "@mui/material";
import {DialogActions, Button} from "@mui/material";
const AddEditPartsComponent = () => {
    return (
      <div>
    <DialogActions sx={{ marginY: 2 }}>


      <Button variant="contained">
        View 
      </Button>


      </DialogActions>
      </div>
    );
  };

  export default AddEditPartsComponent;
