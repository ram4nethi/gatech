import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Snackbar,
} from '@mui/material';

const UpdatePartsForm = ({ onClose }) => {
  const [partNumber, setPartNumber] = useState('');
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSnackbarOpen, setIsSnackbarOpen] = useState(false);

  useEffect(() => {
    console.log('Fetching part status for partNumber:', partNumber);
  
    const fetchPartStatus = async () => {
      try {
        const response = await fetch(`http://34.230.78.12:3001/api/get-part-status/${partNumber}`);
        const data = await response.json();
  
        if (response.ok) {
          setStatus(data.status);
          setError('');

        } else {
          setError(data.error || 'Error fetching part status');
        }
      } catch (error) {
        console.error('Error fetching part status:', error);
        setError('Error fetching part status');
      }
    };
  
    if (partNumber.trim() !== '') {
      fetchPartStatus();
    } else {
      // Reset status when partNumber is empty
      setStatus('');
    }
  }, [partNumber]);
  

  const handleUpdatePartStatus = async () => {
    try {
      // Validate partNumber
      if (partNumber.trim() === '') {
        setError('Please enter a valid part number.');
        return;
      }

      // Validate the status
      if (status.trim() === '') {
        setError('Please enter a valid status.');
        return;
      }

      // Make API call to update part status
      const response = await fetch(`http://34.230.78.12:3001/api/update-part-status/${partNumber}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Error updating part status');
      }

      setSuccessMessage(data.message);
      setIsSnackbarOpen(true);

      console.log('Part Status Updated Successfully:', data.message);
    } catch (error) {
      console.error('Error updating part status:', error.message);
      setError(error.message || 'Error updating part status');
    }
  };

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
    onClose(); // Close the dialog when the Snackbar is closed
  };

  return (
    <Dialog open={true} onClose={onClose}>
      <DialogTitle>Update Part Status</DialogTitle>
      <DialogContent>
        <TextField
          label="Part Number"
          variant="outlined"
          fullWidth
          value={partNumber}
          onChange={(e) => setPartNumber(e.target.value)}
        />

        <FormControl fullWidth>
          <InputLabel>Status</InputLabel>
          <Select
            label="Status"
            variant="outlined"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <MenuItem value="Ordered">Ordered</MenuItem>
            <MenuItem value="Received">Received</MenuItem>
            <MenuItem value="Installed">Installed</MenuItem>
          </Select>
        </FormControl>

        {/* Display error message */}
        {error && <p style={{ color: 'red' }}>{error}</p>}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleUpdatePartStatus}>Update</Button>
      </DialogActions>

      {/* Snackbar for success message */}
      <Snackbar
        open={isSnackbarOpen}
        autoHideDuration={3000}
        onClose={handleSnackbarClose}
        message={successMessage}
      />
    </Dialog>
  );
};

export default UpdatePartsForm;
