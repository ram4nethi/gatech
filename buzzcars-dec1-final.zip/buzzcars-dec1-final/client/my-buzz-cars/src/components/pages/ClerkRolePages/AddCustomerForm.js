import React, { useState } from 'react';
import { Paper, TextField, Button, Typography, Grid, Box, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import { toast } from 'react-toastify';
import { useEffect } from 'react';

import 'react-toastify/dist/ReactToastify.css';

const AddCustomerForm = ({onAddCustomer}) => {

  const [customerId, setCustomerId] = useState('');
  const [customerIds, setCustomerIds] = useState([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [isBusiness, setIsBusiness] = useState(false); 

  const [personData, setPersonData] = useState({
    driverlicensenumber:'',
    customerid: '',
    firstname: '',
    lastname: '',
    street: '',
    city: '',
    state: '',
    postalcode: '',
    email: '',
    phonenumber: '',
  });

  const [businessData, setBusinessData] = useState({
    taxidentificationnumber: '',
    customerid: '',
    email: '',
    businessname: '',
    phonenumber: '',
    primarycontactfirstname: '',
    primarycontactlastname: '',
    street: '',
    city: '',
    state: '',
    postalcode: '',
  });

const handleInputChange = (e) => {
  const { name, value } = e.target;

  if (isBusiness) {
    // Update businessData when adding a business
    setBusinessData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  } else {
    // Update personData when adding a person
    setPersonData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  }
};




  useEffect(() => {
    // Fetch customer IDs when the form opens
    const fetchCustomerIds = async () => {
    try {
        const response = await fetch('http://34.230.78.12:3001/api/customers');
        const data = await response.json();

        setCustomerIds(data);
    } catch (error) {
        console.error('Error fetching customer IDs:', error);
    }
    };

    fetchCustomerIds();
}, []);


  


  const handleAddCustomer = async () => {
    

    const customerData={
      customerid:customerId,
    };

    console.log(customerId, "my cust id ");

    
    try {
      const response = await fetch('http://34.230.78.12:3001/api/add-customer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(customerData),
      });

      const result = await response.json();

      if (result.success) {
        setCustomerIds((prevCustomerIds) => [...prevCustomerIds, customerId]);
        alert('Customer added successfully');
      } else {
        alert('Error adding customer: ' + result.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An unexpected error occurred');
    }
  };


  const handleAddPerson = async () => {

    //FOrm Validation
    const requiredFields = ['driverlicensenumber', 'firstname', 'lastname', 'street', 'city', 'state', 'postalcode', 'email', 'phonenumber'];
    const missingFields = requiredFields.filter((field) => !personData[field]);

    if (missingFields.length > 0) {
      // Display error toast for missing fields
      toast.error(`Please enter values for the following fields: ${missingFields.join(', ')}`);
      return;
    }

    // Additional format validation (you can customize this based on your requirements)

    // Check if customerid is a number
    // if (isNaN(personData.customerid)) {
    //   toast.error('Customer ID must be a number');
    //   return;
    // }

    // Check if phonenumber is a valid phone number
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(personData.phonenumber)) {
      toast.error('Please enter a valid phone number (10 digits)');
      return;
    }

    // Check if email is a valid email address
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(personData.email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    // If all validations pass, proceed with adding the customer
    // For now, just log the customer data to the console
    console.log('Person Data:', personData);

    const personDataWithCustomerId = {
      ...personData,
      customerid: selectedCustomerId, // or use customerId if it's appropriate
    };

    try {
      const response = await fetch('http://34.230.78.12:3001/api/add-person', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(personDataWithCustomerId),
      });

      const result = await response.json();

      if (result.success) {
        alert('Person added successfully');
        // Reset the form or perform any other actions on successful submission
      } else {
        alert('Error adding customer: ' + result.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An unexpected error occurred');
    }

    // You can now proceed with the database insertion queries
  };

  const handleAddBusiness = async () => {
    // Form Validation for Business
    const requiredFields = ['taxidentificationnumber', 'email', 'businessname', 'phonenumber', 'primarycontactfirstname', 'primarycontactlastname', 'street', 'city', 'state', 'postalcode'];
    const missingFields = requiredFields.filter((field) => !businessData[field]);

    if (missingFields.length > 0) {
      // Display error toast for missing fields
      toast.error(`Please enter values for the following fields: ${missingFields.join(', ')}`);
      return;
    }

    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(businessData.phonenumber)) {
      toast.error('Please enter a valid phone number (10 digits)');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(businessData.email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    const businessDataWithCustomerId = {
      ...businessData,
      customerid: selectedCustomerId,
    };

    try {
      const response = await fetch('http://34.230.78.12:3001/api/add-business', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(businessDataWithCustomerId),
      });

      const result = await response.json();

      if (result.success) {
        alert('Business added successfully');
      } else {
        alert('Error adding business: ' + result.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An unexpected error occurred');
    }
  };



  return (
    <div>
      <Paper elevation={3} style={{ padding: '20px', marginTop: '20px', textAlign: 'center' }}>
        <Typography variant="h5" style={{ marginBottom: '15px' }}>
          Add Customer Form
        </Typography>

        <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <TextField
          label="customer id"
          onChange={(e) => setCustomerId(e.target.value)}
          name='customerid'
          type="number"
          value={customerId}
          variant='outlined'
          fullWidth
          style={{ marginBottom: '20px' }}
          />
          </Grid>
          </Grid>
          <Button
          variant="contained"
          onClick={handleAddCustomer}
          style={{ background: '#4CAF50', color: 'white', borderRadius: '5px', cursor: 'pointer', marginTop: '20px' }}
        >
          Add Customer
        </Button>


        <Typography variant="h5" style={{ marginBottom: '15px', marginTop: '20px' }}>
          Select Type:
        </Typography>

        <FormControl variant="outlined" style={{ marginBottom: '20px' }}>
          <InputLabel>Type</InputLabel>
          <Select
            value={isBusiness ? 'business' : 'person'}
            onChange={(e) => setIsBusiness(e.target.value === 'business')}
            label="Type"
          >
            <MenuItem value="person">Person</MenuItem>
            <MenuItem value="business">Business</MenuItem>
          </Select>
        </FormControl>

        {isBusiness ? (
          // Render business form fields
          <div>
            <Typography variant="h5" style={{ marginBottom: '15px' }}>
              Add Business Form
            </Typography>

            <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
  <TextField
    label="Tax Identification Number"
    variant="outlined"
    name="taxidentificationnumber"
    type="number"
    value={businessData.taxidentificationnumber}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="Business Name"
    variant="outlined"
    name="businessname"
    value={businessData.businessname}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>
<Grid item xs={12} sm={6}>

<Box sx={{ marginBottom: 2 }}>
      <FormControl fullWidth variant="outlined">
      <InputLabel id="customer-id-label">Customer ID</InputLabel>
      <Select
          labelId="customer-id-label"
          id="customer-id"
          value={selectedCustomerId}
          onChange={(e) => setSelectedCustomerId(e.target.value)}
          label="CustomerID"
      >
          {customerIds.map((customerId) => (
          <MenuItem key={customerId} value={customerId}>
              {customerId}
          </MenuItem>
          ))}
      </Select>
      </FormControl>
  </Box>
  </Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="Primary Contact First Name"
    variant="outlined"
    name="primarycontactfirstname"
    value={businessData.primarycontactfirstname}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="Primary Contact Last Name"
    variant="outlined"
    name="primarycontactlastname"
    value={businessData.primarycontactlastname}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="Email"
    variant="outlined"
    name="email"
    value={businessData.email}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="Phone Number"
    variant="outlined"
    name="phonenumber"
    type="number"
    value={businessData.phonenumber}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="Street"
    variant="outlined"
    name="street"
    value={businessData.street}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="City"
    variant="outlined"
    name="city"
    value={businessData.city}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="State"
    variant="outlined"
    name="state"
    value={businessData.state}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>

<Grid item xs={12} sm={6}>
  <TextField
    label="Postal Code"
    variant="outlined"
    name="postalcode"
    type="number"
    value={businessData.postalcode}
    onChange={handleInputChange}
    fullWidth
    style={{ marginBottom: '20px' }}
  />
</Grid>
            </Grid>

            <Button
              variant="contained"
              onClick={handleAddBusiness}
              style={{ background: '#4CAF50', color: 'white', borderRadius: '5px', cursor: 'pointer', marginTop: '20px' }}
            >
              Add Business
            </Button>
          </div>
        ) : (
          // Render person form fields
          <div>
        <Typography variant="h5" style={{ marginBottom: '15px' }}>
          Add Person Form
        </Typography>

          <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
            <TextField
              label="Driving License Number ID"
              variant="outlined"
              name="driverlicensenumber"
              type="number"
              value={personData.driverlicensenumber}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>

          <Box sx={{ marginBottom: 2 }}>
                <FormControl fullWidth variant="outlined">
                <InputLabel id="customer-id-label">Customer ID</InputLabel>
                <Select
                    labelId="customer-id-label"
                    id="customer-id"
                    value={selectedCustomerId}
                    onChange={(e) => setSelectedCustomerId(e.target.value)}
                    label="CustomerID"
                >
                    {customerIds.map((customerId) => (
                    <MenuItem key={customerId} value={customerId}>
                        {customerId}
                    </MenuItem>
                    ))}
                </Select>
                </FormControl>
            </Box>
            </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="First Name"
              variant="outlined"
              name="firstname"
              value={personData.firstname}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Last Name"
              variant="outlined"
              name="lastname"
              value={personData.lastname}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Street"
              variant="outlined"
              name="street"
              value={personData.street}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="City"
              variant="outlined"
              name="city"
              value={personData.city}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="State"
              variant="outlined"
              name="state"
              value={personData.state}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Postal Code"
              variant="outlined"
              name="postalcode"
              type="number"
              value={personData.postalcode}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Email"
              variant="outlined"
              name="email"
              value={personData.email}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <TextField
              label="Phone Number"
              variant="outlined"
              name="phonenumber"
              type="number"
              value={personData.phonenumber}
              onChange={handleInputChange}
              fullWidth
              style={{ marginBottom: '20px' }}
            />
          </Grid>
        </Grid>

        <Button
          variant="contained"
          onClick={handleAddPerson}
          style={{ background: '#4CAF50', color: 'white', borderRadius: '5px', cursor: 'pointer', marginTop: '20px' }}
        >
          Add Person
        </Button>
        </div>
        )}
      </Paper>
    </div>
  );
};

export default AddCustomerForm;
