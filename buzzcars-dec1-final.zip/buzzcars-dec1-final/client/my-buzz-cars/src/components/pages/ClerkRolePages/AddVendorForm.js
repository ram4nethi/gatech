// AddVendorForm.js
import React, { useState, useEffect } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField } from '@mui/material';
import AddPartsForm from './AddPartsForm';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const AddVendorForm = ({ onClose, onSave }) => {
  const [vendorName, setVendorName] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [showAddPartsForm, setShowAddPartsForm] = useState(false);

  const handleSave = async () => {
    // Validate form fields
    if (!vendorName || !street || !city || !state || !postalCode || !phoneNumber) {
      alert('Please enter all required values.');
      return;
    }

    // Save vendor data to the database
    try {
      const response = await fetch('http://34.230.78.12:3001/api/add-vendor', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vendorname: vendorName,
          street: street,
          city: city,
          state: state,
          postalcode: postalCode,
          phonenumber: phoneNumber,
        }),
      });

      const result = await response.json();


      console.log(vendorName, street, city, state, postalCode, phoneNumber, "Values.........");

      if (result.success) {
        console.log('Vendor added successfully:', result.vendor);
        toast.success('Vendor added successfully!');
        setShowAddPartsForm(true);
      } else {
        console.error('Failed to add vendor:', result.error);
        toast.error('Failed to add vendor. Please try again.');
      }
    } catch (error) {
      console.error('Error adding vendor:', error);
      toast.error('An unexpected error occurred. Please try again.');
    }

  };

  useEffect(() => {
    // Check if showAddPartsForm is true and trigger any additional logic here
    if (showAddPartsForm) {
      // You can add any additional logic here if needed
    }
  }, [showAddPartsForm]);

  return (

    <>
    <Dialog open={true} onClose={onClose}>
      <DialogTitle>Add Vendor</DialogTitle>
      <DialogContent>
        <TextField
          label="Vendor Name"
          variant="outlined"
          fullWidth
          value={vendorName}
          onChange={(e) => setVendorName(e.target.value)}
        />
        <TextField
          label="Street"
          variant="outlined"
          fullWidth
          value={street}
          onChange={(e) => setStreet(e.target.value)}
        />
        <TextField
          label="City"
          variant="outlined"
          fullWidth
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <TextField
          label="State"
          variant="outlined"
          fullWidth
          value={state}
          onChange={(e) => setState(e.target.value)}
        />
        <TextField
          label="Postal Code"
          variant="outlined"
          type='number'
          fullWidth
          value={postalCode}
          onChange={(e) => setPostalCode(e.target.value)}
        />
        <TextField
          label="Phone Number"
          variant="outlined"
          type='number'
          fullWidth
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave}>Save</Button>
      </DialogActions>
    </Dialog>

    {showAddPartsForm && (
        <AddPartsForm
          onClose={() => setShowAddPartsForm(false)}
          vendorName={vendorName} // Pass the vendor name to AddPartsForm for prepopulation
        />
      )}
    </>
  );
};

export default AddVendorForm;
