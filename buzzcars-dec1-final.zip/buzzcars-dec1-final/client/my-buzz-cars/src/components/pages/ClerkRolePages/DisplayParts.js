import React, { useState, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TextField,
  Button,
  Typography,
} from '@mui/material';

const DisplayPartsComponent = () => {
  const [parts, setParts] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [error, setError] = useState('');

  const fetchParts = async () => {
    try {
      const response = await fetch(`http://34.230.78.12:3001/api/part-order/${searchText}`);
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      if (data.length === 0) {
        setError('No parts found for the given VIN.');
      } else {
        setParts(data);
        setError('');
      }
    } catch (error) {
      console.error('Error fetching parts:', error);
    }
  };

  const handleSearch = () => {
    fetchParts();
  };

  return (
    <div>
      <h2>Displayed Parts</h2>
      <TextField
        label="Search by VIN"
        variant="outlined"
        margin="normal"
        onChange={(event) => setSearchText(event.target.value)}
      />
      <Button variant="contained" onClick={handleSearch}>
        Search
      </Button>
      {error && <Typography variant="body1" color="error">{error}</Typography>}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Part Number</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Vendor</TableCell>
              <TableCell>Part Order Number</TableCell>
              <TableCell>Cost (in USD)</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Quantity</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {parts.map((part) => (
              <TableRow key={`${part.partordernumber}-${part.partnumber}`}>
                <TableCell>{part.partnumber}</TableCell>
                <TableCell>{part.description}</TableCell>
                <TableCell>{part.vendorname}</TableCell>
                <TableCell>{part.partordernumber}</TableCell>
                <TableCell>{part.cost / 100}</TableCell>
                <TableCell>{part.status}</TableCell>
                <TableCell>{part.quantity}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default DisplayPartsComponent;
