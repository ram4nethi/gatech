import React, { useState, useEffect } from "react";
import { Typography, Dialog, DialogActions,DialogTitle, DialogContent, Button } from "@mui/material";
import SearchBar from "../../SearchBar"; // Import your SearchBar component
import Table from "../../Table"; // Import your Table component
import AddVehicleForm from "../ClerkRolePages/AddVehiclePage";
import ViewReportsComponent from "../ManagerRolePage/ViewReportsComponent";
import DetailVSalesForm from "../SalesRolePages/DetailVFormSales";

const Owner = () => {
  const [isInventoryDialogOpen, setIsInventoryDialogOpen] = useState(false);
  const [filteredData, setFilteredData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedViewItem, setSelectedViewItem] = useState(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [isAddVehicleDialogOpen, setIsAddVehicleDialogOpen] = useState(false);
  const [isReportsDialogOpen, setIsReportsDialogOpen] = useState(false);


  const handleViewInventory = () => {
    setIsInventoryDialogOpen(true);
  };

  const handleCloseInventoryDialog = () => {
    setIsInventoryDialogOpen(false);
  };

  const handleOpenAddVehicleDialog = () => {
    setIsAddVehicleDialogOpen(true);
  };
  
  const handleCloseAddVehicleDialog = () => {
    setIsAddVehicleDialogOpen(false);
  };
  const handleNavigate = () => {
    // Open the Reports Dialog
    setIsReportsDialogOpen(true);
  };

  const handleCloseReportsDialog = () => {
    // Close the Reports Dialog
    setIsReportsDialogOpen(false);
  };


  
  const closeViewDialog = () => {
    setViewDialogOpen(false);
    setSelectedItem(null);
  };

  const handleViewClick = (item) => {
    setSelectedItem(item);
    setViewDialogOpen(true);
  };

    
  useEffect(() => {
    const handleSearch = async () => {
      try {
        setIsLoading(true);

        const response = await fetch('http://54.90.194.32:3001/api/vehicles');
        const data = await response.json();

        //setVehicleCount(data.length);
        setFilteredData(data);

      } catch (error) {
        console.error('Error fetching or filtering data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    handleSearch();
  }, []);

  useEffect(() => {
    const handleSearch = async () => {
      try {
        setIsLoading(true);

        const response = await fetch('http://54.90.194.32:3001/api/vehicles');
        const data = await response.json();

        //setVehicleCount(data.length);
        setFilteredData(data);

      } catch (error) {
        console.error('Error fetching or filtering data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    handleSearch();
  }, []);


  const handleSearch = async (filters) => {
    try {
      setIsLoading(true);
  
      const response = await fetch('http://54.90.194.32:3001/api/vehicles');
      const data = await response.json();
  
      // Apply filtering based on the received data
      const filtered = data.filter((item) => {
        const searchTextMatch =
          item.manufacturername.toLowerCase().includes(filters.searchText.toLowerCase()) ||
          item.modelname.toLowerCase().includes(filters.searchText.toLowerCase());
  
        const modelTypeMatch = filters.modelType === '' || item.vehicletype.toLowerCase() === filters.modelType.toLowerCase();
        const modelYearMatch = filters.modelYear === '' || item.modelyear.toString() === filters.modelYear;
        const vinMatch = filters.vin === '' || item.vin.toLowerCase() === filters.vin.toLowerCase(); // Added VIN filtering

        return searchTextMatch && modelTypeMatch && modelYearMatch && vinMatch;
      });
      console.log(filtered);
      console.log(data.length);
      //setVehicleCount(data.length);
      setFilteredData(filtered);
    } catch (error) {
      console.error('Error fetching or filtering data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <DialogActions sx={{ marginY: 2 }}>
        <Button variant="contained" onClick={handleOpenAddVehicleDialog}>
          Add Vehicle
        </Button>

        <Button variant="contained" onClick={handleViewInventory}>
          View Inventory
        </Button>

        <Button variant="contained" onClick={handleNavigate}>
          View Reports
        </Button>
      </DialogActions>



      
      <Dialog open={isReportsDialogOpen} onClose={handleCloseReportsDialog}>
        <DialogTitle>View Reports</DialogTitle>
        <DialogContent>
          {/* Include the ViewReportsComponent in the Reports Dialog */}
          <ViewReportsComponent />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseReportsDialog} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>



              <Dialog open={isAddVehicleDialogOpen} onClose={handleCloseAddVehicleDialog}>
          <DialogTitle>Add Vehicle</DialogTitle>
          <DialogContent>
            {/* Include your Add Vehicle Form component */}
            <AddVehicleForm />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseAddVehicleDialog}>Cancel</Button>
            {/* Add save logic here if needed */}
          </DialogActions>
        </Dialog>

      {/* Inventory Dialog */}
      <Dialog open={isInventoryDialogOpen} onClose={handleCloseInventoryDialog} fullWidth>
        <Typography variant="h6" component="div" sx={{ textAlign: 'center', marginTop: 2 }}>
          Inventory
        </Typography>
        <SearchBar onSearch={handleSearch} />
          <Table data={filteredData} onViewClick={handleViewClick} />
          <DetailVSalesForm open={viewDialogOpen} onClose={closeViewDialog} selectedItem={selectedItem} />
        <DialogActions>
          {/* Include the SearchBar and Table components in the Inventory Dialog */}
          <Button onClick={handleCloseInventoryDialog} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Owner;
