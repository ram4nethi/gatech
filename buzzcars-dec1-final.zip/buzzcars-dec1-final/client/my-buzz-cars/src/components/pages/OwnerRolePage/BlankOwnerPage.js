import React from "react";
import { Typography } from "@mui/material";
import {DialogActions, Button} from "@mui/material";
import Owner from "./OwnerPage";
const BlankOwnerPage = () => {
    return (
      <div>
    <DialogActions sx={{ marginY: 2 }}>


      </DialogActions>
      </div>
    );
  };

  export default BlankOwnerPage;