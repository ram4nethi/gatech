import React, { useEffect, useState } from "react";
import { Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from "@mui/material";

const PricePerConditionComponent = () => {
  const [pricePerConditionData, setPricePerConditionData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPricePerCondition = async () => {
      try {
        const response = await fetch('http://34.230.78.12:3001/api/price-per-condition');
        const data = await response.json();

        if (response.ok) {
          setPricePerConditionData(data);
        } else {
          console.error('Error fetching price per condition data:', data.error);
        }
      } catch (error) {
        console.error('Error fetching price per condition data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPricePerCondition();
  }, []);

  return (
    <div>

      {loading ? (
        <p>Loading...</p>
      ) : pricePerConditionData ? (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Vehicle Type</TableCell>
                <TableCell>Excellent Average Price</TableCell>
                <TableCell>Very Good Average Price</TableCell>
                <TableCell>Good Average Price</TableCell>
                <TableCell>Fair Average Price</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pricePerConditionData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell>{row.vehicletype}</TableCell>
                  <TableCell>{row.excellentaverageprice}</TableCell>
                  <TableCell>{row.verygoodaverageprice}</TableCell>
                  <TableCell>{row.goodaverageprice}</TableCell>
                  <TableCell>{row.fairaverageprice}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      ) : (
        <p>Error fetching price per condition data</p>
      )}
    </div>
  );
};

export default PricePerConditionComponent;
