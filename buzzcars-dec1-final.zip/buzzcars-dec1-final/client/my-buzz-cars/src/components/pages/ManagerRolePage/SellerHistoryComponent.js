import React, { useState, useEffect } from "react";
import {
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TextField,
  Button,
} from "@mui/material";

const SellerHistoryComponent = () => {
  const [sellerHistoryData, setSellerHistoryData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchText, setSearchText] = useState("");

  const fetchSellerHistory = async () => {
    try {
      const response = await fetch(`http://54.90.194.32:3001/api/seller-history?businessname=${searchText}`);
      const data = await response.json();

      if (response.ok) {
        setSellerHistoryData(data);
      } else {
        console.error('Error fetching seller history data:', data.error);
      }
    } catch (error) {
      console.error('Error fetching seller history data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSellerHistory();
  }, [searchText]);

  return (
    <div>
     


      {loading ? (
        <p>Loading...</p>
      ) : sellerHistoryData ? (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Seller Name</TableCell>
                <TableCell>Total Vehicles Sold</TableCell>
                <TableCell>Average Purchase Price</TableCell>
                <TableCell>Average Parts per Vehicle</TableCell>
                <TableCell>Average Part Cost</TableCell>
                <TableCell>Lower Quality Indicator</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {sellerHistoryData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell>{row.sellername}</TableCell>
                  <TableCell>{row.totalvehiclessold}</TableCell>
                  <TableCell>{row.averagepurchaseprice}</TableCell>
                  <TableCell>{row.averagepartspervehicle}</TableCell>
                  <TableCell>{row.averagepartcost}</TableCell>
                  <TableCell>{row.LowerQualityIndicator}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      ) : (
        <p>Error fetching seller history data</p>
      )}
    </div>
  );
};

export default SellerHistoryComponent;
