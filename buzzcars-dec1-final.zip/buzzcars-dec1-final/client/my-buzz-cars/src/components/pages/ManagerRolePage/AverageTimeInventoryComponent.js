import React, { useEffect, useState } from "react";
import { Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from "@mui/material";

const AverageTimeInventoryComponent = () => {
  const [averageTimeData, setAverageTimeData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAverageTimeData = async () => {
      try {
        const response = await fetch('http://34.230.78.12:3001/api/average-time-inventory');
        const data = await response.json();

        if (response.ok) {
          setAverageTimeData(data);
        } else {
          console.error('Error fetching average time data:', data.error);
        }
      } catch (error) {
        console.error('Error fetching average time data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAverageTimeData();
  }, []);

  return (
    <div>
      <h1>Average Time in Inventory</h1>

      {loading ? (
        <p>Loading...</p>
      ) : averageTimeData ? (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Vehicle Type</TableCell>
                <TableCell>Average Days in Inventory</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {averageTimeData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell>{row.vehicletype}</TableCell>
                  <TableCell>{row.avgdaysininventory}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      ) : (
        <p>Error fetching average time data</p>
      )}
    </div>
  );
};

export default AverageTimeInventoryComponent;
