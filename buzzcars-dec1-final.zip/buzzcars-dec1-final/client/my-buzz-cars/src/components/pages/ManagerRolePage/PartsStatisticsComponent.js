import React, { useEffect, useState } from "react";
import { Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from "@mui/material";

const PartsStatisticsComponent = () => {
  const [partsStatisticsData, setPartsStatisticsData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPartsStatistics = async () => {
      try {
        const response = await fetch('http://54.90.194.32:3001/api/parts-statistics');
        const data = await response.json();

        if (response.ok) {
          setPartsStatisticsData(data);
        } else {
          console.error('Error fetching parts statistics data:', data.error);
        }
      } catch (error) {
        console.error('Error fetching parts statistics data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPartsStatistics();
  }, []);

  return (
    <div>

      {loading ? (
        <p>Loading...</p>
      ) : partsStatisticsData ? (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Vendor Name</TableCell>
                <TableCell>Number of Parts Supplied</TableCell>
                <TableCell>Total Dollar Amount Spent on Parts</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {partsStatisticsData.map((row, index) => (
                <TableRow key={index}>
                  <TableCell>{row.vendorname}</TableCell>
                  <TableCell>{row.numberofparts}</TableCell>
                  <TableCell>{row.totalamountspent}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      ) : (
        <p>Error fetching parts statistics data</p>
      )}
    </div>
  );
};

export default PartsStatisticsComponent;
