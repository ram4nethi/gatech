import React, { useState, useEffect } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';

const SalesReportTable = () => {
  const [salesData, setSalesData] = useState([]);

  useEffect(() => {
    const fetchSalesReport = async () => {
      try {
        const response = await fetch('http://54.90.194.32:3001/api/sales-report');
        const data = await response.json();

        if (response.ok) {
          setSalesData(data);
        } else {
          console.error('Error fetching sales report:', data);
        }
      } catch (error) {
        console.error('Error fetching sales report:', error);
      }
    };

    fetchSalesReport();
  }, []);

  return (
    <div>
    
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Sales Year</TableCell>
              <TableCell>Sales Month</TableCell>
              <TableCell>Total Vehicles Sold</TableCell>
              <TableCell>Total Purchase Price</TableCell>
              <TableCell>Total Net</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {salesData.map((record) => (
              <TableRow key={record.email}>
                <TableCell>{record.year}</TableCell>
                <TableCell>{record.month}</TableCell>
                <TableCell>{record.totalvehiclessold}</TableCell>
                <TableCell>{record.totalsalesincome}</TableCell>
                <TableCell>{record.totalnetincome}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default SalesReportTable;
