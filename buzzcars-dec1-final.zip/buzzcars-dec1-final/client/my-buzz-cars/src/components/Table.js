// Table.js
import React, { useEffect, useState } from 'react';
import {
  Table as MuiTable,
  TableBody,
  TableCell,
  Button,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
} from '@mui/material';

const Table = (props) => {
  useEffect(() => {
    // Log the authenticated role whenever it changes
    console.log('Authenticated Role in Table........................:', props.authenticatedRole);
  }, [props.authenticatedRole]);


  const [myData, setMyData] = useState([]);


  useEffect(() => {
    // Fetch the count from the server
    const fetchTableData = async () => {
      try {
        const response = await fetch('http://34.230.78.12:3001/api/public-screen');
        const data = await response.json();

        if (response.ok) {
          setMyData(data);
        } else {
          console.error('Error fetching table Data:', data);
        }
      } catch (error) {
        console.error('Error fetching table data:', error);
      }
    };

    fetchTableData();
  }, []);

  console.log(myData, "Tabular data in the public screen")

  const getColumnsBasedOnRole = () => {
    const commonColumns = [
      "vin",
      'manufacturername',
      'modelname',
      'vehicletype',
      'modelyear',
      'fueltype',
      'mileage',
      'colors',
      'salesprice'
    ];

    const clerkOwnerColumns = [
      ...commonColumns,
      'vin',
      'mileage',
      'description',
      'condition',
      'purchaseprice',
      'purchasedate',
      'salesprice',
    ];

    const salesPersonColumns = [
      ...commonColumns,
      'mileage',
      'description',
      'salesprice',
    ];

    const managerColumns = [
      // Add additional columns for the 'MANAGER' role if needed
      ...commonColumns,
      'vin',
      'mileage',
      'description',
      'condition',
      'purchaseprice',
      'purchasedate',
      'salesprice',
    ];
    

    switch (props.authenticatedRole) {
      case 'INV_CLERK':
      case 'OWNER':
        return clerkOwnerColumns;
      case 'SALES_PERSON':
        return salesPersonColumns;
      case 'MANAGER':
        return managerColumns;
      default:
        return commonColumns;
    }
  };
  // Call getColumnsBasedOnRole() once and store the result
  const columns = getColumnsBasedOnRole();

  const handleViewClick = (item) => {
    if (props.onViewClick) {
      props.onViewClick(item);
    }
  };

  return (
    <Box margin={2} marginBottom={2}>
    <TableContainer component={Paper} style={styles.container}>
      <MuiTable>
        <TableHead>
          <TableRow>
            {columns.map((column, index) => (
              <TableCell key={index}>
                <b>{column}</b>
              </TableCell>
            ))}
            <TableCell></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {/* {props.data.map((item) => (
            <TableRow key={item.vin}>
              {columns.map((column, index) => (
                <TableCell key={`${item.vin}_${index}`}>
                  {item[column]}
                </TableCell>
              ))} */}
            {(props.authenticatedRole === null ? myData : props.data).map((item) => (
            <TableRow key={item.vin}>
              {columns.map((column, index) => (
                <TableCell key={`${item.vin}_${index}`}>
                  {item[column]}
                </TableCell>
              ))}
              <TableCell>
                {props.authenticatedRole === null || (
                  <Button
                    variant="contained"
                    onClick={() => handleViewClick(item)}
                    style={{
                      background: '#2196F3',
                      color: 'white',
                      borderRadius: '5px',
                      cursor: 'pointer',
                    }}
                  >
                    View
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </MuiTable>
    </TableContainer>
  </Box>
  );
};

const styles = {
  container: {
    marginTop: '20px',
  },
};

export default Table;
