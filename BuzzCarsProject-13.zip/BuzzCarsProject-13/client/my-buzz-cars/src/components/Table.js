// Table.js
import React, { useEffect } from 'react';
import {
  Table as MuiTable,
  TableBody,
  TableCell,
  Button,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
} from '@mui/material';

const Table = (props) => {
  useEffect(() => {
    // Log the authenticated role whenever it changes
    console.log('Authenticated Role in Table........................:', props.authenticatedRole);
  }, [props.authenticatedRole]);

  const getColumnsBasedOnRole = () => {
    const commonColumns = [
      'manufacturername',
      'modelname',
      'vehicletype',
      'modelyear',
      'fueltype',
    ];

    const clerkOwnerColumns = [
      ...commonColumns,
      'vin',
      'mileage',
      'description',
      'condition',
      'purchaseprice',
      'purchasedate',
      'salesprice',
    ];

    const salesPersonColumns = [
      ...commonColumns,
      'mileage',
      'description',
      'salesprice',
    ];

    const managerColumns = [
      // Add additional columns for the 'MANAGER' role if needed
      ...commonColumns,
      'vin',
      'mileage',
      'description',
      'condition',
      'purchaseprice',
      'purchasedate',
      'salesprice',
    ];

    switch (props.authenticatedRole) {
      case 'INV_CLERK':
      case 'OWNER':
        return clerkOwnerColumns;
      case 'SALES_PERSON':
        return salesPersonColumns;
      case 'MANAGER':
        return managerColumns;
      default:
        return commonColumns;
    }
  };
  // Call getColumnsBasedOnRole() once and store the result
  const columns = getColumnsBasedOnRole();

  const handleViewClick = (item) => {
    if (props.onViewClick) {
      props.onViewClick(item);
    }
  };

  return (
    <Box margin={2} marginBottom={2}>
      <TableContainer component={Paper} style={styles.container}>
        <MuiTable>
          <TableHead>
            <TableRow>
              {columns.map((column, index) => (
                <TableCell key={index}>
                  <b>{column}</b>
                </TableCell>
              ))}
              <TableCell></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {props.data.map((item) => (
              <TableRow key={item.vin}>
                {columns.map((column, index) => (
                  <TableCell key={`${item.vin}_${index}`}>
                    {item[column]}
                  </TableCell>
                ))}
                <TableCell>
                  <Button
                    variant="contained"
                    onClick={() => handleViewClick(item)}
                    style={{
                      background: '#2196F3',
                      color: 'white',
                      borderRadius: '5px',
                      cursor: 'pointer',
                    }}
                  >
                    View
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </MuiTable>
      </TableContainer>
    </Box>
  );
};

const styles = {
  container: {
    marginTop: '20px',
  },
};

export default Table;
