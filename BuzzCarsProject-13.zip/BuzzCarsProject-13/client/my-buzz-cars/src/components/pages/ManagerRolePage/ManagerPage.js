import React from "react";
import { Button, Typography, Dialog, DialogContent, DialogTitle } from "@mui/material";
import {useEffect, useState } from 'react';
import SearchBar from '../../SearchBar'; 
import Table from '../../Table'; 
import { Paper, Box, Card, CardContent } from '@mui/material';
import {DialogActions} from "@mui/material";
import VehicleDetailForm from "./VehicleDetailMForm";
import { useNavigate } from "react-router-dom";
import ViewReportsComponent from "./ViewReportsComponent";


const Manager = ({selectedItem, onClose}) => {
  const [searchResults, setSearchResults] = useState([]);
  const [vehicleCount, setVehicleCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true); // Add loading state
  const [filteredData, setFilteredData] = useState([]);
  const [isViewClicked, setisViewClicked] = useState(false);
  const [selectedViewItem, setSelectedViewItem] = useState(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [poCount, setPoCount] = useState(null);
  const [purchaseCount, setPurchaseCount] = useState(0);
  const [carsAvailablePurchaseCount, setCarsAvailablePurchaseCount] = useState('');
  const [isReportsDialogOpen, setIsReportsDialogOpen] = useState(false);  // State for the Reports Dialog
  const navigate = useNavigate();





  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://54.90.194.32:3001/api/po-count');
        const data = await response.json();

        if (data.poCount) {
          setPoCount(data.poCount);
        } else {
          console.error('Error fetching part order count:', data.error);
        }
      } catch (error) {
        console.error('Error fetching part order count:', error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    // Fetch the count of vehicles from the server
    const fetchVehicleCount = async () => {
      try {
        const response = await fetch('http://54.90.194.32:3001/countItems');
        const data = await response.json();

        if (response.ok) {
          const countValue = data[0]["COUNT(v.vin)"];
          setVehicleCount(countValue);
        } else {
          console.error('Error fetching vehicle count:', data);
        }
      } catch (error) {
        console.error('Error fetching vehicle count:', error);
      }
    };

    fetchVehicleCount();
  }, []);


  useEffect(() => {
    const handleSearch = async () => {
      try {
        setIsLoading(true);

        const response = await fetch('http://54.90.194.32:3001/api/purchase-count');
        const data = await response.json();

     
        const countValue = data[0]["purchased_count"];
        setPurchaseCount(countValue);

      } catch (error) {
        console.error('Error fetching or filtering data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    handleSearch();
  }, []);

  useEffect(() => {
    const fetchPoCount = async () => {
      try {
        setIsLoading(true);
  
        const response = await fetch('http://54.90.194.32:3001/api/po-count');
        const data = await response.json();
  
        if (response.ok) {
          const poCountValue = data.poCount;
          setPoCount(poCountValue);  // Add this line to set the poCount in state
        } else {
          console.error('Error fetching part order count:', data);
        }
      } catch (error) {
        console.error('Error fetching part order count:', error);
      } finally {
        setIsLoading(false);
      }
    };
  
    fetchPoCount();
  }, []);


  useEffect(() => {
    // Fetch the count of vehicles from the server
    const carCountPurchase = async () => {
      try {
        const response = await fetch('http://54.90.194.32:3001/cars-available-purchase');
        const data = await response.json();

        if (response.ok) {
          const countAvailablePurchase = data[0]["count(vin)"];
          setCarsAvailablePurchaseCount(countAvailablePurchase);
        } else {
          console.error('Error fetching vehicle count:', data);
        }
      } catch (error) {
        console.error('Error fetching vehicle count:', error);
      }
    };

    carCountPurchase();
  }, []);

  
  useEffect(() => {
    const handleSearch = async () => {
      try {
        setIsLoading(true);

        const response = await fetch('http://54.90.194.32:3001/api/vehicles');
        const data = await response.json();

        //setVehicleCount(data.length);
        setFilteredData(data);

      } catch (error) {
        console.error('Error fetching or filtering data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    handleSearch();
  }, []);

  const handleViewClick = (item) => {
    setSelectedViewItem(item);
    setIsDetailDialogOpen(true);
  };

  const handleNavigate = () => {
    // Open the Reports Dialog
    setIsReportsDialogOpen(true);
  };

  const handleCloseReportsDialog = () => {
    // Close the Reports Dialog
    setIsReportsDialogOpen(false);
  };

  const handleSearch = async (filters) => {
    try {
      setIsLoading(true);
  
      const response = await fetch('http://54.90.194.32:3001/api/vehicles');
      const data = await response.json();
  
      // Apply filtering based on the received data
      const filtered = data.filter((item) => {
        const searchTextMatch =
          item.manufacturername.toLowerCase().includes(filters.searchText.toLowerCase()) ||
          item.modelname.toLowerCase().includes(filters.searchText.toLowerCase());
  
        const modelTypeMatch = filters.modelType === '' || item.vehicletype.toLowerCase() === filters.modelType.toLowerCase();
        const modelYearMatch = filters.modelYear === '' || item.modelyear.toString() === filters.modelYear;
  
        return searchTextMatch && modelTypeMatch && modelYearMatch;
      });
      console.log(filtered);
      console.log(data.length);
      //setVehicleCount(data.length);
      setFilteredData(filtered);
    } catch (error) {
      console.error('Error fetching or filtering data:', error);
    } finally {
      setIsLoading(false);
    }
  };




    return (
      <div style={{display:'inline-flex'}}>
      <Paper elevation={3} style={{ padding: '20px', marginTop: '20px', textAlign: 'center', width:'80%', }}>
        
        <div style={{display:'flex'}}>


        <Card style={{ maxWidth: '200px', margin: 'auto', marginBottom: '20px' }}>
          <CardContent>
            <Typography variant="h6" component="div">
              Total number of cars available
            </Typography>
            <Typography variant="h4" component="div">
              {vehicleCount}
            </Typography>
          </CardContent>
        </Card>

        <Card style={{ maxWidth: '200px', margin: 'auto', marginBottom: '20px' }}>
        <CardContent>
          <Typography variant="h6" component="div">
            Total Cars with parts pending:
          </Typography>
          <Typography variant="h4" component="div">
            {poCount}
          </Typography>
        </CardContent>
        </Card>


        <Card style={{ maxWidth: '200px', margin: 'auto', marginBottom: '20px' }}>
          <CardContent>
            <Typography variant="h6" component="div">
              Total cars available for purchase
            </Typography>
            <Typography variant="h4" component="div">
              {carsAvailablePurchaseCount}
            </Typography>
          </CardContent>
        </Card>
        
        <Card style={{ maxWidth: '200px', margin: 'auto', marginBottom: '20px' }}>
          <CardContent>
            <Typography variant="h6" component="div">
              Cars Previously Purchased Count
            </Typography>
            <Typography variant="h4" component="div">
              {purchaseCount}
            </Typography>
          </CardContent> 
        </Card>
        </div>
        <SearchBar onSearch={handleSearch} />
        <Table data={filteredData} onViewClick={handleViewClick} />

        {isDetailDialogOpen && (
        <VehicleDetailForm
          open={isDetailDialogOpen}
          onClose={() => setIsDetailDialogOpen(false)}
          selectedItem={selectedViewItem}
        />
      )}

      </Paper>

      <div style={{ marginTop: '20px' }}>
        <Button variant="contained" style={{ height: '50px', marginRight: '10px' }} onClick={handleNavigate}>
          View Reports
        </Button>
      </div>


      <Dialog open={isReportsDialogOpen} onClose={handleCloseReportsDialog}>
        <DialogTitle>View Reports</DialogTitle>
        <DialogContent>
          {/* Include the ViewReportsComponent in the Reports Dialog */}
          <ViewReportsComponent />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseReportsDialog} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
    );
  };

  export default Manager;