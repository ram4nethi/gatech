import React, { useState } from 'react';
import { Button, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import SellerHistoryComponent from './SellerHistoryComponent';
import AverageTimeInventoryComponent from './AverageTimeInventoryComponent';
import PricePerConditionComponent from './PricePerConditionComponent';
import PartsStatisticsComponent from './PartsStatisticsComponent';
import MonthlySalesComponent from './MonthlySalesComponent';
import SalesReportTable from './SalesReportTable';

const ViewReportsComponent = ({ onClose }) => {
  const [selectedTask, setSelectedTask] = useState(null);

  const openDialog = (task) => {
    setSelectedTask(task);
  };

  const closeDialog = () => {
    setSelectedTask(null);
  };

  const buttonStyle = {
    height: '70px',
    width: '200px',
    fontSize: '20px',
    marginBottom: '10px',
    marginRight: '20px', // Adjust the margin for spacing
  };

  const renderDialogContent = () => {
    switch (selectedTask) {
      case 'SellerHistory':
        return <SellerHistoryComponent onClose={closeDialog} />;
      case 'AverageTimeInInventory':
        return <AverageTimeInventoryComponent onClose={closeDialog} />;
      case 'PricePerCondition':
        return <PricePerConditionComponent onClose={closeDialog} />;
      case 'PartsStatistics':
        return <PartsStatisticsComponent onClose={closeDialog} />;
      case 'MonthlySales':
        return <MonthlySalesComponent onClose={closeDialog} />;
        case 'SalesReport':
        return <SalesReportTable onClose={closeDialog} />;
      default:
        return null;
    }
  };

  return (
    <div>
      <Button style={buttonStyle} variant="contained" onClick={() => openDialog('SellerHistory')}>
        Seller History
      </Button>
      <Button style={buttonStyle} variant="contained" onClick={() => openDialog('AverageTimeInInventory')}>
        Average Time In Inventory
      </Button>
      <Button style={buttonStyle} variant="contained" onClick={() => openDialog('PricePerCondition')}>
        Price Per Condition
      </Button>
      <Button style={buttonStyle} variant="contained" onClick={() => openDialog('PartsStatistics')}>
        Parts Statistics
      </Button>
      <Button style={buttonStyle} variant="contained" onClick={() => openDialog('MonthlySales')}>
        Monthly Sales
      </Button>
      <Button style={buttonStyle} variant="contained" onClick={() => openDialog('SalesReport')}>
        Sales Report
      </Button>

      <Dialog open={!!selectedTask} onClose={closeDialog}>
        <DialogTitle>{selectedTask}</DialogTitle>
        <DialogContent>
          {renderDialogContent()}
        </DialogContent>
        <DialogActions>
          <Button onClick={closeDialog}>Close</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default ViewReportsComponent;
